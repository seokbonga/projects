﻿namespace WindowsFormsApp2
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.N1 = new System.Windows.Forms.Label();
            this.N2 = new System.Windows.Forms.Label();
            this.N3 = new System.Windows.Forms.Label();
            this.N4 = new System.Windows.Forms.Label();
            this.N5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.W1 = new System.Windows.Forms.Label();
            this.W2 = new System.Windows.Forms.Label();
            this.W3 = new System.Windows.Forms.Label();
            this.W4 = new System.Windows.Forms.Label();
            this.W5 = new System.Windows.Forms.Label();
            this.N6 = new System.Windows.Forms.Label();
            this.W6 = new System.Windows.Forms.Label();
            this.tboxResult = new System.Windows.Forms.TextBox();
            this.SelectNumber = new System.Windows.Forms.Button();
            this.WinningResult = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(415, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "로또 번호 뽑기";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(93, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "뽑은 번호 :";
            // 
            // N1
            // 
            this.N1.AutoSize = true;
            this.N1.Location = new System.Drawing.Point(252, 130);
            this.N1.Name = "N1";
            this.N1.Size = new System.Drawing.Size(37, 24);
            this.N1.TabIndex = 2;
            this.N1.Text = "N1";
            // 
            // N2
            // 
            this.N2.AutoSize = true;
            this.N2.Location = new System.Drawing.Point(338, 130);
            this.N2.Name = "N2";
            this.N2.Size = new System.Drawing.Size(37, 24);
            this.N2.TabIndex = 3;
            this.N2.Text = "N2";
            // 
            // N3
            // 
            this.N3.AutoSize = true;
            this.N3.Location = new System.Drawing.Point(444, 130);
            this.N3.Name = "N3";
            this.N3.Size = new System.Drawing.Size(37, 24);
            this.N3.TabIndex = 4;
            this.N3.Text = "N3";
            // 
            // N4
            // 
            this.N4.AutoSize = true;
            this.N4.Location = new System.Drawing.Point(538, 130);
            this.N4.Name = "N4";
            this.N4.Size = new System.Drawing.Size(37, 24);
            this.N4.TabIndex = 5;
            this.N4.Text = "N4";
            // 
            // N5
            // 
            this.N5.AutoSize = true;
            this.N5.Location = new System.Drawing.Point(636, 130);
            this.N5.Name = "N5";
            this.N5.Size = new System.Drawing.Size(37, 24);
            this.N5.TabIndex = 6;
            this.N5.Text = "N5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(93, 194);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "당첨 번호 : ";
            // 
            // W1
            // 
            this.W1.AutoSize = true;
            this.W1.Location = new System.Drawing.Point(246, 194);
            this.W1.Name = "W1";
            this.W1.Size = new System.Drawing.Size(43, 24);
            this.W1.TabIndex = 8;
            this.W1.Text = "W1";
            // 
            // W2
            // 
            this.W2.AutoSize = true;
            this.W2.Location = new System.Drawing.Point(332, 194);
            this.W2.Name = "W2";
            this.W2.Size = new System.Drawing.Size(43, 24);
            this.W2.TabIndex = 9;
            this.W2.Text = "W2";
            // 
            // W3
            // 
            this.W3.AutoSize = true;
            this.W3.Location = new System.Drawing.Point(438, 194);
            this.W3.Name = "W3";
            this.W3.Size = new System.Drawing.Size(43, 24);
            this.W3.TabIndex = 10;
            this.W3.Text = "W3";
            // 
            // W4
            // 
            this.W4.AutoSize = true;
            this.W4.Location = new System.Drawing.Point(532, 194);
            this.W4.Name = "W4";
            this.W4.Size = new System.Drawing.Size(43, 24);
            this.W4.TabIndex = 11;
            this.W4.Text = "W4";
            // 
            // W5
            // 
            this.W5.AutoSize = true;
            this.W5.Location = new System.Drawing.Point(636, 194);
            this.W5.Name = "W5";
            this.W5.Size = new System.Drawing.Size(43, 24);
            this.W5.TabIndex = 12;
            this.W5.Text = "W5";
            // 
            // N6
            // 
            this.N6.AutoSize = true;
            this.N6.Location = new System.Drawing.Point(726, 130);
            this.N6.Name = "N6";
            this.N6.Size = new System.Drawing.Size(37, 24);
            this.N6.TabIndex = 13;
            this.N6.Text = "N6";
            // 
            // W6
            // 
            this.W6.AutoSize = true;
            this.W6.Location = new System.Drawing.Point(720, 194);
            this.W6.Name = "W6";
            this.W6.Size = new System.Drawing.Size(43, 24);
            this.W6.TabIndex = 14;
            this.W6.Text = "W6";
            // 
            // tboxResult
            // 
            this.tboxResult.Location = new System.Drawing.Point(97, 272);
            this.tboxResult.Name = "tboxResult";
            this.tboxResult.Size = new System.Drawing.Size(665, 35);
            this.tboxResult.TabIndex = 15;
            // 
            // SelectNumber
            // 
            this.SelectNumber.Location = new System.Drawing.Point(97, 348);
            this.SelectNumber.Name = "SelectNumber";
            this.SelectNumber.Size = new System.Drawing.Size(200, 78);
            this.SelectNumber.TabIndex = 16;
            this.SelectNumber.Text = "새로 뽑기";
            this.SelectNumber.UseVisualStyleBackColor = true;
            this.SelectNumber.Click += new System.EventHandler(this.SelectNumber_Click);
            // 
            // WinningResult
            // 
            this.WinningResult.Location = new System.Drawing.Point(363, 348);
            this.WinningResult.Name = "WinningResult";
            this.WinningResult.Size = new System.Drawing.Size(200, 78);
            this.WinningResult.TabIndex = 17;
            this.WinningResult.Text = "당첨 확인";
            this.WinningResult.UseVisualStyleBackColor = true;
            this.WinningResult.Click += new System.EventHandler(this.WinningResult_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.Location = new System.Drawing.Point(622, 348);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(141, 78);
            this.CloseButton.TabIndex = 18;
            this.CloseButton.Text = "종료";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1356, 624);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.WinningResult);
            this.Controls.Add(this.SelectNumber);
            this.Controls.Add(this.tboxResult);
            this.Controls.Add(this.W6);
            this.Controls.Add(this.N6);
            this.Controls.Add(this.W5);
            this.Controls.Add(this.W4);
            this.Controls.Add(this.W3);
            this.Controls.Add(this.W2);
            this.Controls.Add(this.W1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.N5);
            this.Controls.Add(this.N4);
            this.Controls.Add(this.N3);
            this.Controls.Add(this.N2);
            this.Controls.Add(this.N1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form5";
            this.Text = "Lotto";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label N1;
        private System.Windows.Forms.Label N2;
        private System.Windows.Forms.Label N3;
        private System.Windows.Forms.Label N4;
        private System.Windows.Forms.Label N5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label W1;
        private System.Windows.Forms.Label W2;
        private System.Windows.Forms.Label W3;
        private System.Windows.Forms.Label W4;
        private System.Windows.Forms.Label W5;
        private System.Windows.Forms.Label N6;
        private System.Windows.Forms.Label W6;
        private System.Windows.Forms.TextBox tboxResult;
        private System.Windows.Forms.Button SelectNumber;
        private System.Windows.Forms.Button WinningResult;
        private System.Windows.Forms.Button CloseButton;
    }
}